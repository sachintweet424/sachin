//
//  ViewController.swift
//  McKinleyTask
//
//  Created by 1THING on 07/11/19.
//  Copyright © 2019 Innotical. All rights reserved.
//

import UIKit
import SVProgressHUD

class ViewController: UIViewController {

    @IBOutlet weak var idField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func loginBtnTap(_ sender: UIButton) {
        self.hitLoginApi()
    }
    func hitLoginApi(){
        SVProgressHUD.show()
        let param : [String : Any] = [self.idField.text ?? "" : self.passwordField.text ?? ""]
        api_manager.POSTApi(registerUrl(), param: param, header: nil) { (response, error, statuscode) in
            print(response)
            SVProgressHUD.dismiss()
           
            if let error = error {
                print(error.localizedDescription)
                //self.showErrorViewofType(.ServerError,"",error: error)
            }
            else if let json = response{
                print(json)
                if json["success"].boolValue{
                    let vc = WebVC.storyboardInstance()
                    vc?.urlStr = "https://mckinleyrice.com/?token=QpwL5tke4Pnpja7X4*"
                    self.navigationController?.pushViewController(vc!, animated: true)
                }else{
                    
                }
            }
        }
    }
}

