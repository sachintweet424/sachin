//
//
import Foundation
import UIKit

let main = UIStoryboard.init(name: "Main", bundle: nil)

extension ViewController{
    class func storyboardInstance()-> ViewController?{
        return main.instantiateViewController(withIdentifier: "ViewController") as? ViewController
    }
    
    class func navigation()-> UINavigationController?{
        return main.instantiateViewController(withIdentifier: "login") as? UINavigationController
    }
}

extension WebVC{
    class func storyboardInstance()-> WebVC?{
        return main.instantiateViewController(withIdentifier: "WebVC") as? WebVC
    }
    
    
}

