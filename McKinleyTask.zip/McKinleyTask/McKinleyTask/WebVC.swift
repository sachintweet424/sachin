//
//  WebVC.swift
//  McKinleyTask
//
//  Created by 1THING on 07/11/19.
//  Copyright © 2019 Innotical. All rights reserved.
//

import UIKit

class WebVC: UIViewController {

    @IBOutlet weak var webView: UIWebView!
    var urlStr = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL (string: self.urlStr)
        let requestObj = URLRequest(url: url!)
        webView.loadRequest(requestObj)
        // Do any additional setup after loading the view.
    }
    


}
